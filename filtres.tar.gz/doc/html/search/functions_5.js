var searchData=
[
  ['monochrome',['monochrome',['../filtre_8c.html#a5c54f88c8c173fdabe2e65cc8544c8dd',1,'monochrome(PNM *image, char *couleur):&#160;filtre.c'],['../filtre_8h.html#a94af484629a3f72770adf8dde71d506f',1,'monochrome(PNM *image, char *couleur):&#160;filtre.c']]]
];
