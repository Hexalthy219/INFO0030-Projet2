var searchData=
[
  ['retournement',['retournement',['../filtre_8c.html#aaf91f74c958de4a5d9730b6c54c0e441',1,'retournement(PNM *image):&#160;filtre.c'],['../filtre_8h.html#a9d907932a1a11f5c3d236ce7a985b5b2',1,'retournement(PNM *image):&#160;filtre.c']]]
];
