var searchData=
[
  ['ecrit_5fen_5ftete_5ffichier_5fpnm',['ecrit_en_tete_fichier_PNM',['../pnm_8c.html#ad306d3e9a2c2cf0c3f8fb8341edd7b24',1,'ecrit_en_tete_fichier_PNM(PNM *image, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a0c7b94083e37bfad848fb4680182476d',1,'ecrit_en_tete_fichier_PNM(PNM *image, FILE *fichier):&#160;pnm.c']]],
  ['ecrit_5fimage_5fdans_5ffichier',['ecrit_image_dans_fichier',['../pnm_8c.html#af128e2933320390c3dbb683ca893310c',1,'ecrit_image_dans_fichier(PNM *image, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a7fbce762c3908e9b108a68cf154dbeb7',1,'ecrit_image_dans_fichier(PNM *image, FILE *fichier):&#160;pnm.c']]]
];
