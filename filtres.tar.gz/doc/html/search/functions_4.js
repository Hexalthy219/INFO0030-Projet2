var searchData=
[
  ['libere_5fpnm',['libere_PNM',['../pnm_8c.html#a78c4fab83adfae65fe9640be111aad98',1,'libere_PNM(PNM **image):&#160;pnm.c'],['../pnm_8h.html#ae78d1c9a1c861c86b5b1bd7cbff31352',1,'libere_PNM(PNM **image):&#160;pnm.c']]],
  ['lit_5fdimensions_5fimage',['lit_dimensions_image',['../pnm_8c.html#ad6294ddbfca47734e30fe63e2414f10b',1,'lit_dimensions_image(int *nbr_ligne, int *nbr_colonne, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a97483c7efd2beb3c7eab42bb968bf162',1,'lit_dimensions_image(int *nbr_ligne, int *nbr_colonne, FILE *fichier):&#160;pnm.c']]],
  ['lit_5fvaleur_5fmax',['lit_valeur_max',['../pnm_8c.html#aeeabfe70318a6f0835b1ead98dcb3d07',1,'lit_valeur_max(unsigned int *valeur_max, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a572a34740dd0c45a4c9a2f0572ac44c7',1,'lit_valeur_max(unsigned int *valeur_max, FILE *fichier):&#160;pnm.c']]],
  ['load_5fpnm',['load_pnm',['../pnm_8c.html#a718d3667eb03777d1b038cc27919c850',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c'],['../pnm_8h.html#adf533a1bc155f9ee83d90c5a1564468f',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c']]]
];
