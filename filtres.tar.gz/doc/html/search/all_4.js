var searchData=
[
  ['gris',['gris',['../filtre_8c.html#a2ee6eb00c9ca0b84802b49d21ac07a2a',1,'gris(PNM *image, char *technique):&#160;filtre.c'],['../filtre_8h.html#a5b150d6e2f0a4f35865249658a6fa829',1,'gris(PNM *image, char *technique):&#160;filtre.c']]]
];
