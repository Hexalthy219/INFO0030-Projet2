var searchData=
[
  ['negatif',['negatif',['../filtre_8c.html#a4b0749fa055e91b71a12d769176d1beb',1,'negatif(PNM *image):&#160;filtre.c'],['../filtre_8h.html#acbef35d52284634e010540a832c0b102',1,'negatif(PNM *image):&#160;filtre.c']]],
  ['noir_5fblanc',['noir_blanc',['../filtre_8c.html#ad9094d0242b12ac2bfc5ee0fcc21a98c',1,'noir_blanc(PNM *image, char *seuil):&#160;filtre.c'],['../filtre_8h.html#a31ca8b7fa0381fcb27c64ac5a6f46c76',1,'noir_blanc(PNM *image, char *seuil):&#160;filtre.c']]]
];
