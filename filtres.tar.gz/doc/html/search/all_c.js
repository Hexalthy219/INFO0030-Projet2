var searchData=
[
  ['write_5fpnm',['write_pnm',['../pnm_8c.html#abacefd8f607a15722b28889b8b8b9f2c',1,'write_pnm(PNM *image, char *filename):&#160;pnm.c'],['../pnm_8h.html#af899a2931ee1eaa8ecb6a313710ff228',1,'write_pnm(PNM *image, char *filename):&#160;pnm.c']]]
];
