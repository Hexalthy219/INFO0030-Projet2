var searchData=
[
  ['verifie_5fcorrespondance_5fextension_5fformat',['verifie_correspondance_extension_format',['../pnm_8c.html#aa0ca5e297113f50d1ce73c7b5e176ddf',1,'verifie_correspondance_extension_format(int type_image, char *filename, int *extension_fichier):&#160;pnm.c'],['../pnm_8h.html#ab3914a3df9e22c627b675e3ccf77cb84',1,'verifie_correspondance_extension_format(int type_image, char *filename, int *extension_fichier):&#160;pnm.c']]],
  ['verifie_5fextension_5ffichier',['verifie_extension_fichier',['../pnm_8c.html#ace3abbbb0b504391176615e94a2a2c96',1,'verifie_extension_fichier(char *filename, PNM *image):&#160;pnm.c'],['../pnm_8h.html#ab4f8fcacdbe1266567e33c733239b4bc',1,'verifie_extension_fichier(char *filename, PNM *image):&#160;pnm.c']]],
  ['verifie_5fnombre_5fmagique',['verifie_nombre_magique',['../pnm_8c.html#a28e17291cdf63300dbb59568d8d86c02',1,'verifie_nombre_magique(int *type, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a327d10f173286ccf1a37475b66b160d3',1,'verifie_nombre_magique(int *type, FILE *fichier):&#160;pnm.c']]],
  ['verifie_5fvalidite_5ffilename',['verifie_validite_filename',['../pnm_8c.html#ad0efacadc06756d3a11483cf42d08c37',1,'verifie_validite_filename(char *filename):&#160;pnm.c'],['../pnm_8h.html#a3cd49ff792cfb6e8b51a0d22915e6c0c',1,'verifie_validite_filename(char *filename):&#160;pnm.c']]]
];
