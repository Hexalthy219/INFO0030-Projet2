var searchData=
[
  ['changer_5fformat',['changer_format',['../pnm_8c.html#a2537cebb6d8b5ac756e3d438ed10bb97',1,'changer_format(PNM *image, int format):&#160;pnm.c'],['../pnm_8h.html#ab3ed3c1b817a2d35bdaaf68b921b1978',1,'changer_format(PNM *image, int format):&#160;pnm.c']]],
  ['changer_5fvaleur_5fpixel_5fpnm',['changer_valeur_pixel_PNM',['../pnm_8c.html#a9008c01845758d67924e8642d6ebdfdc',1,'changer_valeur_pixel_PNM(PNM *image, int numero_ligne, int numero_colonne, unsigned short valeur[]):&#160;pnm.c'],['../pnm_8h.html#a27b23c910b5d73509d9898a517596ca5',1,'changer_valeur_pixel_PNM(PNM *image, int numero_ligne, int numero_colonne, unsigned short valeur[]):&#160;pnm.c']]],
  ['charge_5fvaleurs_5ffichier',['charge_valeurs_fichier',['../pnm_8c.html#a9412a3439d5292cc35a6c821c86f7448',1,'charge_valeurs_fichier(PNM *image, FILE *fichier):&#160;pnm.c'],['../pnm_8h.html#a18ba34f739742484398a01733aa2037b',1,'charge_valeurs_fichier(PNM *image, FILE *fichier):&#160;pnm.c']]],
  ['constructeur_5fpnm',['constructeur_PNM',['../pnm_8c.html#a6317f5428de83115789d7ac41e3b1fc8',1,'constructeur_PNM(int nbr_ligne, int nbr_colonne, int format, unsigned int valeur_max):&#160;pnm.c'],['../pnm_8h.html#ad2e5674819399a1d2b07ac2043fb1b67',1,'constructeur_PNM(int nbr_ligne, int nbr_colonne, int format, unsigned int valeur_max):&#160;pnm.c']]]
];
